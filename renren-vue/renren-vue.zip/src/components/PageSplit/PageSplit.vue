<template>
  <div class="tpl-wrapper">
    <div class="detail_divider">
    </div>
  </div>
</template>

<script>
  /**
   * 页面灰色分割线
   */
  export default {
    name: "PageSplit"
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>
  .detail_divider
    display: flex;
    overflow: hidden;
    width: 100%;
    height: 10.8px;
    background-color: #f8f8f8;
    position: relative;
</style>
