/**
 * 统一状态管理
 */
export default {
  address: {name:'定位中...'}, // 地址信息对象
  user:{}, //用户信息
  goods:[], //商品列表
  banners:[],
  navs:[],

}
