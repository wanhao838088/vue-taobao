/**
 * 服务器地址
 * @type {string}
 */
export const serverUrl='http://localhost:8060/';

/**
 * 获取验证码地址
 * @type {string}
 */
export const captchaUrl= serverUrl+'code/image?width=90';

//Authorization
export const base64Wanhao = 'Basic d2FuaGFvOndhbmhhb1NlY3JldA==';
