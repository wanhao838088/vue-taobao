/*
mutation type 常量名称模块
*/
export const SAVE_USER_INFO = 'save_user_info'; // 保存用户信息

export const RECEIVE_GOODS = 'receive_goods';

export const SAVE_BANNERS = 'save_banners';

export const SAVE_NAVS = 'save_navs';
